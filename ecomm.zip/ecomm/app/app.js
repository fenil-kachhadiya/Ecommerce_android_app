angular.module('App', [
    'ngMaterial',
    'ngRoute',
    'ngMessages',
    'ngCookies',
    'ngSanitize',
    'cl.paging',
    'textAngular',
    'colorpicker.module'
]);

/* Theme Configuration */
angular.module('App').config(function ($mdThemingProvider) {
    // Primary color palette
    var myPrimary = $mdThemingProvider.extendPalette('green', {
        '500': '4DB151',
        'contrastDefaultColor': 'light'
    });

    // Accent color palette
    var myAccent = $mdThemingProvider.extendPalette('yellow', {
        '500': 'FFDE26'
    });

    $mdThemingProvider.definePalette('myPrimary', myPrimary);
    $mdThemingProvider.definePalette('myAccent', myAccent);

    $mdThemingProvider.theme('default')
        .primaryPalette('myPrimary')
        .accentPalette('myAccent');
});

/* Route Configuration */
angular.module('App').config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/dashboard', {
            templateUrl: 'view/dashboard/dashboard.html',
            controller: 'DashboardController'
        })

        .when('/order', {
            templateUrl: 'view/order/list.html',
            controller: 'OrderController'
        })
        .when('/create_order', {
            templateUrl: 'view/order/create.html',
            controller: 'AddOrderController'
        })

        .when('/product', {
            templateUrl: 'view/product/list.html',
            controller: 'ProductController'
        })
        .when('/create_product', {
            templateUrl: 'view/product/create.html',
            controller: 'AddProductController'
        })

        .when('/category', {
            templateUrl: 'view/category/list.html',
            controller: 'CategoryController'
        })
        .when('/create_category', {
            templateUrl: 'view/category/create.html',
            controller: 'AddCategoryController'
        })

        .when('/news', {
            templateUrl: 'view/news/list.html',
            controller: 'NewsController'
        })
        .when('/create_news', {
            templateUrl: 'view/news/create.html',
            controller: 'AddNewsController'
        })

        .when('/shipping', {
            templateUrl: 'view/shipping/list.html',
            controller: 'ShippingController'
        })

        .when('/setting', {
            templateUrl: 'view/setting/setting.html',
            controller: 'SettingController'
        })

        .when('/login', {
            templateUrl: 'view/login.html',
            controller: 'LoginController'
        })

        .otherwise({
            redirectTo: '/login'
        });

    // Optional:
    // .when('/notification', { templateUrl: 'view/notification/list.html', controller: 'NotificationController' });
    // .when('/application', { templateUrl: 'view/application/list.html', controller: 'ApplicationController' });
    // .when('/about', { templateUrl: 'view/about/about.html', controller: 'AboutController' });
}]);

/* Focus Factory */
angular.module('App').factory('focus', function ($timeout, $window) {
    return function (id) {
        $timeout(function () {
            var element = $window.document.getElementById(id);
            if (element) element.focus();
        });
    };
});

/* Run Block - Login Guard */
angular.module('App').run(function ($location, $rootScope, $cookies) {
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        // Can add dynamic page titles if needed
    });

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        $rootScope.isLogin = true;

        if (!$rootScope.isCookieExist()) {
            $location.path('/login');
        } else {
            $rootScope.isLogin = false;
        }
    });
});

/* Custom Filter - Cut */
angular.module('App').filter('cut', function () {
    return function (value, wordwise, max, tail) {
        if (!value) return '';
        max = parseInt(max, 10);
        if (!max) return value;
        if (value.length <= max) return value;

        value = value.substr(0, max);
        if (wordwise) {
            var lastspace = value.lastIndexOf(' ');
            if (lastspace !== -1) {
                if (value.charAt(lastspace - 1) === '.' || value.charAt(lastspace - 1) === ',') {
                    lastspace = lastspace - 1;
                }
                value = value.substr(0, lastspace);
            }
        }

        return value + (tail || ' …');
    };
});
