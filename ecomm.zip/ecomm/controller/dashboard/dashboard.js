angular.module('App').controller('DashboardController', function ($rootScope, $scope, $http, $mdToast, $cookies, request, $timeout) {
    var self = $scope;
    var root = $rootScope;

    root.closeAndDisableSearch();
    root.toolbar_menu = null;
    $rootScope.pagetitle = 'Dashboard';

   function createChart(canvasId, chartType, labels, data, colors) {
    $timeout(function () {
        var ctx = document.getElementById(canvasId);
        if (ctx) {
            new Chart(ctx, {
                type: chartType,
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Data', // Label for the legend
                        data: data,
                        backgroundColor: colors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom'
                        },
                        datalabels: {
                            anchor: 'center',
                            align: 'center',
                            color: '#fff',
                            font: {
                                weight: 'bold',
                                size: 14
                            },
                            formatter: function (value, context) {
                                return value;
                            }
                        }
                    }
                }
            });
        }
    }, 200);
}


    // Product/Order/Category Data
    request.getDashboardProduct().then(function (resp) {
        if (resp && resp.data) {
            self.order = resp.data.order || {};
            self.product = resp.data.product || {};
            self.category = resp.data.category || {};

            createChart('orderChart', 'doughnut', ['Waiting', 'Processed'],
                [self.order.waiting || 0, self.order.processed || 0],
                ['#27ae60', '#2ecc71']);

            createChart('productChart', 'bar',
                ['Published', 'Draft', 'Ready Stock', 'Out of Stock', 'Suspend'],
                [
                    self.product.published || 0,
                    self.product.draft || 0,
                    self.product.ready_stock || 0,
                    self.product.out_of_stock || 0,
                    self.product.suspend || 0
                ],
                ['#229954', '#28b463', '#58d68d', '#82e0aa', '#a9dfbf']);

            createChart('categoryChart', 'pie', ['Published', 'Draft'],
                [self.category.published || 0, self.category.draft || 0],
                ['#1e8449', '#52be80']);
        }
    });

    // News Chart
    request.getDashboardOthers().then(function (resp) {
        if (resp && resp.data) {
            self.news = resp.data.news || {};

            createChart('newsChart', 'bar', ['Featured', 'Published', 'Draft'],
                [self.news.featured || 0, self.news.published || 0, self.news.draft || 0],
                ['#27ae60', '#2ecc71', '#58d68d']);
        }
    });
});
